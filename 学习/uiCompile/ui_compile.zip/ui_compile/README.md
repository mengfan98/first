# Project Title

An blank extension.

## Install

```bash
# Install dependent modules
npm install
# build
npm run build
```
